import { RouterProvider, createBrowserRouter } from "react-router-dom";
import DashboardPage from "./components/DashboardPage";
import { QueryClient, QueryClientProvider } from "react-query";
import LoginPage from "./components/LoginPage";
import AccountPage from "./components/AccountPage";
import Marketplace from "./components/MarketplacePage";
import SubscriptionPage from "./components/SubscriptionPage";

const router = createBrowserRouter([
    {
        path: "/dashboard",
        element: <DashboardPage />,
    },
    {
        path: "/login",
        element: <LoginPage />,
    },
    {
        path: "/account",
        element: <AccountPage />,
    },
    {
        path: "/marketplace",
        element: <Marketplace />,
    },
    {
        path: "/dashboard/:tenantId",
        element: <SubscriptionPage />,
    },
]);
const queryClient = new QueryClient();

const App = () => {
    return (
        <QueryClientProvider client={queryClient}>
            <RouterProvider router={router} />
        </QueryClientProvider>
    );
};

export default App;
