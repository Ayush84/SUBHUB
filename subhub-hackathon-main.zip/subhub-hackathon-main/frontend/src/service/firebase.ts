import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBCVQ60_XoHUsYZelorvd0h-JHJoiblKHk",
  authDomain: "subhub-hackathon.firebaseapp.com",
  projectId: "subhub-hackathon",
  storageBucket: "subhub-hackathon.appspot.com",
  messagingSenderId: "168196455521",
  appId: "1:168196455521:web:c2ae1cef2715abb0b6fe20"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);