interface Subscription {
    name: string;
    amount: number;
    nextRenewalDate: string;
    endDate: string;
    status: "ACTIVE" | "INACTIVE" | "PENDING"; // Add other possible status values here if needed
    productList: null | any[]; // Replace 'any' with a more specific type if possible
}

interface TenantData {
    name: string;
    consumerName: string;
    activeSubscription: number;
    subscriptionList: Subscription[];
}

const tenantData: TenantData = {
    name: "Tenant #9",
    consumerName: "Metaverse",
    activeSubscription: 2,
    subscriptionList: [
        {
            name: "A-S00000001",
            amount: 3.0,
            nextRenewalDate: "2023-08-01T00:00:00.000+00:00",
            endDate: "2024-07-26",
            status: "ACTIVE",
            productList: null,
        },
        {
            name: "A-S00000003",
            amount: 6.0,
            nextRenewalDate: "2023-08-01T00:00:00.000+00:00",
            endDate: "2025-07-26",
            status: "ACTIVE",
            productList: null,
        },
    ],
};

const useSubscriptions = (tenantId: string) => {
    return { data: tenantData };
};

export default useSubscriptions;
