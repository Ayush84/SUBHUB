import { useQuery } from "react-query";

export const DashboardDataMock: DashboardAPIResponseType = {
    totalSubscription: 4,
    paid: 50,
    nmrr: 20,
    budget: {
        amount: 100
    },
    tenants: [
        {
            id: "9",
            name: "Tenant #9",
            activeSubscription: 2,
            mrr: 9.0,
            customerName: "Customer 1",
        },
        {
            id: "9",
            name: "Tenant #9",
            activeSubscription: 2,
            mrr: 18.0,
            customerName: "Customer 2",
        },
        {
            id: "9",
            name: "Tenant #9",
            activeSubscription: 0,
            mrr: null,
            customerName: "Customer 3",
        },
        {
            id: "9",
            name: "Tenant #9",
            activeSubscription: 2,
            mrr: 9.0,
            customerName: "Customer 1",
        },
        {
            id: "9",
            name: "Tenant #9",
            activeSubscription: 2,
            mrr: 18.0,
            customerName: "Customer 2",
        },
    ],
};

export type TenantDataType = {
    id: string;
    name: string;
    activeSubscription: number;
    mrr: number | null;
    customerName: string;
};

export type DashboardAPIResponseType = {
    totalSubscription: number;
    paid: number;
    nmrr: number;
    budget: any;
    tenants: TenantDataType[];
};

const useDashboardData = () => {
    return useQuery<DashboardAPIResponseType, null>(
        ["DASHBOARD_DATA"],
        async () => {
            const res = await fetch("http://localhost:8080/dashboard?consumerId=1");
            const data = await res.json();
            console.log({data,res})
            return data;
        }
    );
};

export default useDashboardData;
