import { useMemo } from "react";
import useDashboardData, { TenantDataType } from "../hooks/useDashboardData";
import Footer from "./Footer";
import Header from "./Header";
import MySubscriptions from "./MySubscriptionSection";
import StatsSection from "./StatsSection";
import TopSubscriptionSection from "./TopSubscriptionSection";

const DashboardPage = () => {

    const { data, isLoading } = useDashboardData();

    const topTenants = useMemo<TenantDataType[]>(() => {
        if(isLoading || !data) return [];
        return data.tenants.slice(0,3) ;
    },[data,isLoading]);

    const remainingTenants = useMemo<TenantDataType[]>(() => {
        if(isLoading || !data) return [];
        return data.tenants.slice(3) ;
    },[data,isLoading]);


    if (isLoading) {
        return <div>Loading...</div>;
    }

    return (
        <div className="min-h-screen bg-slate-100">
            <Header />
            <div className="pt-24"></div>
            <div className="h-full container-sm px-4 mx-auto flex items-center justify-between">
                <StatsSection />
            </div>
            <div className="h-full mt-20 container-sm px-4 mx-auto flex items-center justify-between">
                <TopSubscriptionSection subs={topTenants}/>
            </div>
            <div className="h-full mt-20 container-sm px-4 mx-auto flex items-center justify-between">
                <MySubscriptions subs={remainingTenants} />
            </div>
            <Footer />
        </div>
    );
};

export default DashboardPage;
