export type CircularChatsPropsType = {
    angle?: number;
    gap?: number;
    value?: number;
    size?: number;
    color?: string;
    trackColor?: string;
    trackWidth?: number;
};

const CircularChart = ({
    angle = 0,
    gap = 0,
    size = 100,
    value = 0,
    color = "hsl(220,80%,50%)",
    trackColor = "hsl(220,20%,90%)",
    trackWidth = 8,
}: CircularChatsPropsType) => {
    value = Math.min(1,value);
    const fraction = (360 - gap) / 360;
    return (
        <div style={{ width: size + "px", height: size + "px" }}>
            <svg width={size} height={size} style={{transform:`rotate(${90+angle}deg)`}}>
                <circle
                    cx={size / 2}
                    cy={size / 2}
                    r={(size - trackWidth) / 2}
                    stroke={trackColor}
                    strokeWidth={trackWidth}
                    fill="transparent"
                    pathLength="100"
                    strokeDasharray={`${100 * fraction} 100`}
                    strokeLinecap="round"
                    style={{
                        transform: `rotate(${gap / 2}deg)`,
                        transformOrigin: "50% 50%",
                    }}
                />
                <circle
                    cx={size / 2}
                    cy={size / 2}
                    r={(size - trackWidth) / 2}
                    stroke={color}
                    fill="transparent"
                    strokeWidth={trackWidth}
                    pathLength={100}
                    strokeDasharray={`${100 * fraction} 100`}
                    strokeDashoffset={`${100 * fraction * (1-value)}`}
                    style={{
                        transform: `rotate(${gap / 2}deg)`,
                        transformOrigin: "50% 50%",
                    }}
                    strokeLinecap="round"
                />
            </svg>
        </div>
    );
};

export default CircularChart;
