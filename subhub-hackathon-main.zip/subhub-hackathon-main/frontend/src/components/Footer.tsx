const Footer = () => {
    return (
        <footer className="w-full min-h-[20rem] bg-slate-950 text-slate-300 flex items-center mt-32">
            <div className="h-full w-full mt-8 container-sm px-4 mx-auto flex items-center flex-col justify-between">
                <h3 className="uppercase tracking-[4px] text-teal-500 text-xs">
                    Team Funatics
                </h3>
                <div className="text-center mt-4 font-medium uppercase text-xs">
                    <div>Anurag</div>
                    <div>Ayush</div>
                    <div>Ganesh</div>
                    <div>Ritwik</div>
                    <div>Sarvana</div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
