import {
    IconBrandApple,
    IconBrandGoogle,
    IconBrandWindows,
} from "@tabler/icons-react";
import { ReactComponent as FullLogo } from "../assets/full-logo.svg";
import { auth } from "../service/firebase";
import { AuthProvider, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { useNavigate } from "react-router-dom";

const LoginPage = () => {

    const navigate = useNavigate();

    function handleLogin(){
        let provider: AuthProvider;
        provider = new GoogleAuthProvider();
        signInWithPopup(auth,provider)
        .then((res)=>{
            const credential = GoogleAuthProvider.credentialFromResult(res);
            if(credential){
                const token = credential.accessToken;
                const user = res.user;
                console.log({token,user});
            }
            navigate("/dashboard");
        })

    }


    return (
        <div className="min-w-screen min-h-screen flex items-center justify-center">
            <div className="bg-white p-4 w-full max-w-lg mx-auto rounded-sm">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[12rem] flex items-center flex-col justify-center py-4">
                    <FullLogo height={32} />
                    <div className="text-slate-500 text-center text-sm mt-2 uppercase">The World Subscribed</div>
                </div>
                <div className="flex space-x-2 items-center">
                    <button className="btn flex-1" onClick={()=>handleLogin()}>
                        <IconBrandGoogle />
                        <span className="mx-2">Gooogle</span>
                    </button>
                    <button className="btn flex-1">
                        <IconBrandApple />
                        <span className="mx-2">Apple</span>
                    </button>
                    <button className="btn flex-1">
                        <IconBrandWindows />
                        <span className="mx-2">Microsoft</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;
