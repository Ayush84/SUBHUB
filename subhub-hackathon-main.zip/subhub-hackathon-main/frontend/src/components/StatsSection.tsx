import useDashboardData from "../hooks/useDashboardData";
import CircularChart from "./CircularChart";

const StatsSection = () => {
    const { data, isLoading } = useDashboardData();

    if (isLoading) {
        return <div>Loading...</div>;
    }

    const NmrrBudget = (data?.nmrr || 0) / (data?.budget?.amount || 1) || 0;
    const PaidBudget = (data?.paid || 0) / (data?.budget?.amount || 1) || 0;

    return (
        <div className="flex flex-col items-center w-full">
            <div className="w-full grid grid-cols-3 gap-4 mt-8">
                <div className="p-4 bg-white flex items-center flex-col py-12 rounded-lg">
                    <div className="text-4xl font-black text-slate-900 flex items-center justify-center h-32 w-32 rounded-full border-4 border-teal-400">
                        {data?.totalSubscription || 0}
                    </div>
                    <div className="mt-6 text-slate-500">
                        Active Subscriptions
                    </div>
                </div>
                <div className="p-4 bg-white flex items-center flex-col py-12 rounded-lg select-none">
                    <div className="relative group">
                        <div className="absolute top-[90%] left-1/2 -translate-x-1/2 whitespace-nowrap z-10 opacity-0 transition group-hover:opacity-100 bg-slate-900 text-slate-200 p-2 py-1 rounded-sm">
                            {data?.nmrr.toFixed(2)} / {data?.budget?.amount.toFixed(2)}
                        </div>
                        <CircularChart
                            gap={90}
                            value={NmrrBudget}
                            size={128}
                            color={
                                NmrrBudget > 1
                                    ? "hsl(345,80%,60%)"
                                    : "hsl(172, 66%, 50%)"
                            }
                        />
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center">
                            <span className="text-3xl text-slate-700 font-black">
                                {Math.round(NmrrBudget * 100)}
                            </span>
                            <span className="text-slate-500">%</span>
                        </div>
                    </div>
                    <div className="mt-6 text-slate-500">
                        Net Monthly Amount / Budget
                    </div>
                </div>
                <div className="relative p-4 bg-white flex items-center flex-col py-12 rounded-lg">
                    <div className="relative group">
                        <div className="absolute top-[90%] left-1/2 -translate-x-1/2 whitespace-nowrap z-10 opacity-0 transition group-hover:opacity-100 bg-slate-900 text-slate-200 p-2 py-1 rounded-sm">
                            {data?.paid.toFixed(2)} / {data?.budget?.amount.toFixed(2)}
                        </div>
                        <CircularChart
                            gap={90}
                            value={PaidBudget}
                            size={128}
                            color={
                                NmrrBudget > 1
                                    ? "hsl(345,80%,60%)"
                                    : "hsl(172, 66%, 50%)"
                            }
                        />
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center">
                            <span className="text-3xl text-slate-700 font-black">
                                {Math.round(PaidBudget * 100)}
                            </span>
                            <span className="text-slate-500">%</span>
                        </div>
                    </div>

                    <div className="mt-6 text-slate-500">
                        Payments Done / Budget for year
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StatsSection;
