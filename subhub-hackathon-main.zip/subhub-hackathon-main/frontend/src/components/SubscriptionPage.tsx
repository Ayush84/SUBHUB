import { useParams } from "react-router-dom";
import Footer from "./Footer";
import Header from "./Header";
import useSubscriptions from "../hooks/useSubscriptions";

const SubscriptionPage = () => {
    const { tenantId } = useParams();
    const { data } = useSubscriptions(tenantId || "");

    return (
        <div className="min-h-screen bg-slate-100">
            <Header />
            <div className="pt-24"></div>
            <div className="h-[28rem] container-sm px-4 mx-auto">
                <div className="mt-16 w-full max-w-3xl mx-auto bg-white p-4 rounded-xl">
                    <div className="flex justify-between">
                        <div className="flex">
                            <div className="flex w-14 h-14 items-center justify-center rounded-lg bg-teal-100">
                                <div className="text-2xl text-teal-400">
                                    {data.name[0] || "Z"}
                                </div>
                            </div>
                            <div className="mx-3">
                                <div className="text-xl font-bold text-slate-800">
                                    {data.name}
                                </div>
                                <div className="text-slate-500 mt-1">
                                    Subscribed by {data.consumerName}
                                </div>
                            </div>
                        </div>
                        <div>
                            <StatsCard
                                value={data.activeSubscription}
                                label={"Active Subscription"}
                            />
                        </div>
                    </div>
                    <div className="space-y-2 mt-4">
                        {data.subscriptionList.map((sub) => (
                            <SubsItem key={sub.name} {...sub} />
                        ))}
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default SubscriptionPage;

const StatsCard = ({ value, label }: { value: number; label: string }) => {
    return (
        <div className="p-4 h-full bg-slate-100 rounded-lg flex items-center flex-col justify-between text-slate-700">
            <div className="text-3xl font-bold">{value}</div>
            <div className="text-sm text-center">{label}</div>
        </div>
    );
};

const SubsItem = ({ name, amount, status, endDate }: any) => {
    return (
        <div className="hover:bg-slate-100 p-2 rounded-lg cursor-pointer">
            <div className="flex">
                <div className="flex w-14 h-14 items-center justify-center rounded-lg bg-slate-200">
                    <div className="text-2xl text-slate-400">S</div>
                </div>
                <div className="flex-1 mx-3 flex flex-col justify-between">
                    <div className="text-xl font-bold text-slate-800">
                        <span className="mr-2">{name}</span>
                        {status === "ACTIVE" ? (
                            <span className="text-sm p-1 px-2 rounded-md text-teal-500 bg-teal-100">
                                ACTIVE
                            </span>
                        ) : (
                            <span className="text-sm p-1 px-2 rounded-md text-red-500 bg-red-100">
                                INACTIVE
                            </span>
                        )}
                    </div>
                    <div className="text-sm text-slate-500">
                        Subscription ends on {endDate}
                    </div>
                </div>
                <div className="flex items-center justify-center text-3xl font-bold text-slate-700 text-right" >
                    $ {amount.toFixed(2)}
                </div>
            </div>
        </div>
    );
};
