import { IconBuildingStore, IconChevronRight } from "@tabler/icons-react";
import Footer from "./Footer";
import Header from "./Header";

const Market = [
    {
        id: "Communication",
        name: "Communication",
        products: [
            {
                id: "zoom",
                name: "Zoom",
                image: "/zoom.png",
                desc: "Live Video Calls",
            },
            {
                id: "slack",
                name: "Slack",
                image: "/slack.png",
                desc: "Chat and Messaging",
            },
            {
                id: "discord",
                name: "Discord",
                image: "/discord.png",
                desc: "Chat and Messaging",
            },
        ],
    },
    {
        id: "Online Video Streaming",
        name: "Online Streaming",
        products: [
            {
                id: "youtube",
                name: "YouTube",
                image: "/youtube.png",
                desc: "Videos and Shorts",
            },
            {
                id: "netflix",
                name: "Netflix",
                image: "/netflix.png",
                desc: "Movies and TV Shows",
            },
            {
                id: "Twitch",
                name: "Twitch",
                image: "/twitch.png",
                desc: "Live Streams",
            },
        ],
    },
];

const Marketplace = () => {
    return (
        <div className="min-h-screen bg-slate-100">
            <Header />
            <div className="pt-24"></div>
            <h3 className="text-4xl flex justify-center items-center mt-12 font-bold text-slate-700">
                <IconBuildingStore size={44}/> <span className="mx-3">Marketplace</span>
            </h3>
            <div className="h-full container-sm px-4 mx-auto">
                {Market.map((sec) => (
                    <div className="w-full mx-auto max-w-5xl" key={sec.id}>
                        <h3 className="text-2xl mt-12 font-bold text-slate-900">
                            {sec.name}
                        </h3>
                        <div className="mt-8 w-full grid grid-cols-3 gap-2">
                            {
                                sec.products.map(p => <ProductCard key={p.id} {...p}/>)
                            }
                        </div>
                    </div>
                ))}
            </div>
            <Footer />
        </div>
    );
};

export default Marketplace;

const ProductCard = ({ name, image, desc }: any) => {
    return (
        <div className="flex hover:bg-slate-200 p-2 rounded-lg cursor-pointer group">
            <div className="w-16 h-16 flex items-center justify-center bg-white border border-slate-200 p-4 rounded-md">
                <img className="w-full h-full block" src={image} alt=""/>
            </div>
            <div className="mx-2 flex-1">
                <div className="text-2xl font-bold text-slate-700">{name}</div>
                <div className="text-sm text-slate-500">{desc}</div>
            </div>
            <div className="flex items-center opacity-0 group-hover:opacity-100 text-slate-500 pr-3">
                <IconChevronRight />
            </div>
        </div>
    );
};
