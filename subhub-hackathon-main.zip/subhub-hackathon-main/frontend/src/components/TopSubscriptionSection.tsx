import { TenantDataType } from "../hooks/useDashboardData";
import SubscriptionCard from "./SubscriptionCard";

const TopSubscriptionSection = ({ subs }: { subs: TenantDataType[] }) => {
    return (
        <div className="flex flex-col items-center w-full">
            <h2 className="text-4xl font-bold text-slate-900 text-center">
                Top Subscriptions
            </h2>
            <div className="w-full grid grid-cols-3 gap-4 mt-8">
                {subs.map((sub, i) => (
                    <SubscriptionCard key={i} {...sub} />
                ))}
            </div>
        </div>
    );
};

export default TopSubscriptionSection;
