import Footer from "./Footer";
import Header from "./Header";

const Home = () => {
    return (
        <div className="min-h-screen bg-slate-100">
            <Header />
            <div className="pt-24"></div>
            <div className="h-full container-sm px-4 mx-auto flex items-center justify-between">
                
            </div>
            <Footer />
        </div>
    );
};

export default Home;
