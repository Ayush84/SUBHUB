import {
    IconDashboard,
    IconLogout,
    IconMenuDeep,
    IconPigMoney,
    IconShoppingCart,
    IconUserPlus,
} from "@tabler/icons-react";
import { ReactComponent as FullLogo } from "../assets/full-logo.svg";
import { useState } from "react";
import classNames from "classnames";
import { NavLink, useNavigate } from "react-router-dom";
import { auth } from "../service/firebase";

const Header = () => {
    const [showMenu, setShowMenu] = useState(false);
    const navigate = useNavigate();

    function handleLogout() {
        auth.signOut();
        navigate("/login");
    }

    return (
        <div className="fixed z-20 shadow-md h-24 w-full bg-white">
            <div className="h-full container-sm px-4 mx-auto flex items-center justify-between">
                <div>
                    <button
                        className="btn"
                        onClick={() => navigate("/marketplace")}
                    >
                        <IconShoppingCart />
                        <span>MARKETPLACE</span>
                    </button>
                </div>
                <div className="flex items-center flex-col">
                    <div>
                        <FullLogo height={32} />
                    </div>
                    <div className="text-sm mt-2 text-slate-500">
                        The World Subscribed
                    </div>
                </div>
                <div className="relative">
                    <button
                        className="btn"
                        onClick={() => setShowMenu((s) => !s)}
                    >
                        <IconMenuDeep />
                    </button>
                    <div
                        className={classNames(
                            "absolute right-0 p-2 w-64 bg-white rounded-lg shadow-md border border-slate-200 mt-2 transition-all duration-200 opacity-0 pointer-events-none",
                            { "pointer-events-auto opacity-100": showMenu }
                        )}
                    >
                        <MenuItem
                            icon={<IconDashboard className="text-teal-400" />}
                            name={"Dashboard"}
                            url="/dashboard"
                        />
                        <MenuItem
                            icon={<IconPigMoney className="text-pink-400" />}
                            name={"Edit Budget"}
                            onClick={()=>{}}
                        />
                        <MenuItem
                            icon={<IconUserPlus className="text-red-400" />}
                            name={"Link Account"}
                            url={"/account"}
                        />
                        <MenuItem
                            icon={
                                <IconShoppingCart className="text-amber-400" />
                            }
                            name={"Marketplace"}
                            url={"/marketplace"}
                        />
                        <MenuItem
                            icon={<IconLogout className="text-blue-400" />}
                            name={"Logout"}
                            url={""}
                            onClick={handleLogout}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Header;

const MenuItem = ({
    icon,
    name,
    url,
    onClick = () => {},
}: {
    icon: JSX.Element;
    name: string;
    url?: string;
    onClick?: any;
}) => {
    if (url) {
        return (
            <NavLink to={url}>
                <div className="flex w-full cursor-pointer h-12 rounded items-center space-x-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900">
                    <div className="w-12 flex justify-center items-center">
                        {icon}
                    </div>
                    <div className="">{name}</div>
                </div>
            </NavLink>
        );
    } else {
        return (
            <div
                onClick={onClick}
                className="flex w-full cursor-pointer h-12 rounded items-center space-x-1 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
            >
                <div className="w-12 flex justify-center items-center">
                    {icon}
                </div>
                <div className="">{name}</div>
            </div>
        );
    }
};
