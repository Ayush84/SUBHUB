import { TenantDataType } from "../hooks/useDashboardData";

export type SubscriptionCardType = {
    name: string;
    username: string;
    activeSubscription: number;
    nmrr: number;
};

const SubscriptionCard = ({
    id,
    activeSubscription,
    customerName,
    mrr,
    name
}: TenantDataType) => {
    return (
        <div key={id} className="flex-1 p-4 rounded-xl bg-white cursor-pointer hover:scale-[1.02] transition">
            <div className="flex">
                <div className="flex w-14 h-14 items-center justify-center rounded-lg bg-teal-100">
                    <div className="text-2xl text-teal-400">
                        {name[0] || "Z"}
                    </div>
                </div>
                <div className="mx-3">
                    <div className="text-xl font-bold text-slate-800">
                        {name}
                    </div>
                    <div className="text-slate-500 -mt-1">{customerName}</div>
                </div>
            </div>
            <div className="flex mt-4 space-x-4">
                <div className="flex-1">
                    <StatsCard
                        value={activeSubscription}
                        label={"Active Subscription"}
                    />
                </div>
                <div className="flex-1">
                    <StatsCard value={mrr || 0} label={"Amount"} />
                </div>
            </div>
        </div>
    );
};

export default SubscriptionCard;

const StatsCard = ({ value, label }: { value: number; label: string }) => {
    return (
        <div className="p-4 h-full bg-slate-100 rounded-lg flex items-center flex-col justify-between text-slate-700">
            <div className="text-3xl font-bold">{value}</div>
            <div className="text-sm text-center">{label}</div>
        </div>
    );
};
