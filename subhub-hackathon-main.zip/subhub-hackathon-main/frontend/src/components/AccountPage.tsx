import { IconMailPlus, IconUser } from "@tabler/icons-react";
import Footer from "./Footer";
import Header from "./Header";

const emails = [
    { name: "Ayush Mittal", email: "aymittal@gmail.com" },
    { name: "Ganesh Jayaraman", email: "ganesh@gmail.com" },
];

const AccountPage = () => {
    return (
        <div className="min-h-screen bg-slate-100">
            <Header />
            <div className="pt-24"></div>
            <div className="h-[28rem] container-sm px-4 mx-auto flex items-center justify-between">
                <div className="bg-white rounded-lg p-4 w-full max-w-xl mx-auto mt-8 ">
                    <div className="flex items-center justify-between">
                        <h3 className="text-xl font-bold text-slate-700 px-3">
                            Linked Accounts
                        </h3>
                        <button className="btn">
                            <IconMailPlus />
                            <span className="mx-2">Link new account</span>
                        </button>
                    </div>
                    <div className="mt-4">
                        {emails.map((email) => (
                            <EmailCard {...email} />
                        ))}
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default AccountPage;

const EmailCard = ({ email, name }: { email: string; name: string }) => {
    return (
        <div className="p-4 rounded-md flex hover:bg-slate-100 text-slate-700 hover:text-slate-900 cursor-pointer">
            <div className="flex w-14 h-14 items-center justify-center rounded-lg bg-teal-100">
                <div className="text-2xl text-teal-400">
                    <IconUser />
                </div>
            </div>
            <div className="mx-4">
                <div className="text-xl font-bold">{name}</div>
                <div className="text-slate-500">{email}</div>
            </div>
        </div>
    );
};
