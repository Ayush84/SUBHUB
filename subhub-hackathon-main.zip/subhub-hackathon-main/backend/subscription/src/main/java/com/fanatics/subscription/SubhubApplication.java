package com.fanatics.subscription;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubhubApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubhubApplication.class, args);
	}

}
