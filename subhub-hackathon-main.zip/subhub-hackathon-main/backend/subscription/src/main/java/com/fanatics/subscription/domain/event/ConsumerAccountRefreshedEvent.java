package com.fanatics.subscription.domain.event;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;


public class ConsumerAccountRefreshedEvent {
    private Long consumerId;
    private String emailId;

    public ConsumerAccountRefreshedEvent(Long consumerId, String emailId) {
        this.consumerId = consumerId;
        this.emailId = emailId;
    }

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o, new String[]{});
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, new String[]{});
    }

    @Override
    public String toString() {
        return "ConsumerAccountRefreshedEvent{" +
                "consumerId=" + consumerId +
                ", emailId='" + emailId + '\'' +
                '}';
    }
}
