package com.fanatics.subscription.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.sql.Date;


@Entity
@Table(name = "account")
public class ConsumerAccount {

    private Long consumerId;
    private String name;
    @Column(unique=true, nullable = false)
    private String emailId;
    private String createdBy;
    @Column(name="created_at", columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP", insertable=false, updatable=false)
    private Date createdAt;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public ConsumerAccount() {}

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("emailId")
    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @JsonProperty("createdBy")
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("createdAt")
    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "ConsumerAccount{" +
                "consumerId=" + consumerId +
                ", emailId='" + emailId + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt='" + createdAt + '\'' +
                '}';
    }


    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, 0, new String[] {});
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, new String[] {});
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public static ConsumerAccount createAccount(Long consumerId, String emailId) {
        ConsumerAccount consumerAccount = new ConsumerAccount();
        consumerAccount.setConsumerId(consumerId);
        consumerAccount.setEmailId(emailId);
        consumerAccount.setCreatedBy(emailId);
        return consumerAccount;
    }

    public static ConsumerAccount createAccount(Long consumerId, String emailId, String parentEmailId) {
        ConsumerAccount consumerAccount = new ConsumerAccount();
        consumerAccount.setConsumerId(consumerId);
        consumerAccount.setEmailId(emailId);
        consumerAccount.setCreatedBy(parentEmailId);
        return consumerAccount;
    }
}
