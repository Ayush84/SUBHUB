package com.fanatics.subscription.repository;

import com.fanatics.subscription.domain.Budget;
import com.fanatics.subscription.domain.ConsumerTenantDetails;
import com.fanatics.subscription.domain.SubscriptionDashboardDetails;
import com.fanatics.subscription.domain.Tenant;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class SubscriptionPaymentRepository {

    private EntityManager entityManager;
    private BudgetRepository budgetRepository;

    public SubscriptionPaymentRepository(EntityManager entityManager, BudgetRepository budgetRepository) {
        this.entityManager = entityManager;
        this.budgetRepository = budgetRepository;
    }

    public SubscriptionDashboardDetails getDashboardDetails(List<ConsumerTenantDetails> consumerTenantDetails) {
        if (CollectionUtils.isEmpty(consumerTenantDetails)) {
            return null;
        }
        Integer totalSubscriptions = 0;
        BigDecimal paid = BigDecimal.valueOf(0), nmrr = BigDecimal.valueOf(0);
        List<Tenant> tenantList = new ArrayList<>();
        for (ConsumerTenantDetails consumerTenantDetail : consumerTenantDetails) {
            totalSubscriptions += getTotalSubscriptions(consumerTenantDetail.getTenantId(), consumerTenantDetail.getCustomerId());
            paid = paid.add(getPaid(consumerTenantDetail.getTenantId(), consumerTenantDetail.getCustomerId()));
            tenantList.addAll(getTenantList(consumerTenantDetail.getTenantId(), consumerTenantDetail.getCustomerId()));
        }
        tenantList = tenantList.stream().map(tenant -> {
            if (Objects.isNull(tenant.getMrr())) {
                tenant.setMrr(BigDecimal.valueOf(0));
            }
            return tenant;
        }).sorted(Comparator.comparing(Tenant::getMrr).reversed()).toList();
        nmrr = tenantList.stream().filter(tenant -> Objects.nonNull(tenant.getMrr())).map(tenant -> tenant.getMrr()).reduce(BigDecimal.valueOf(0), this::add);
        Budget budget = getBudget(consumerTenantDetails.get(0).getConsumerId());
        return SubscriptionDashboardDetails.createSubscriptionDashboardDetails(totalSubscriptions, paid, nmrr, budget, tenantList);
    }

    private BigDecimal add(BigDecimal left, BigDecimal right) {
        return left.add(right);
    }

    private int getTotalSubscriptions(String tenantId, String customerId) {
        Query query = entityManager.createNativeQuery("select count(*) from zb_subscription where tenant_id = :tenantId and customer_id = :customerId");
        query.setParameter("tenantId", tenantId);
        query.setParameter("customerId", customerId);
        long count = (Long) query.getSingleResult();
        return (int) count;
    }

    private BigDecimal getPaid(String tenantId, String customerId) {
        Query query = entityManager.createNativeQuery("select sum(amount) from zb_payment where tenant_id = :tenantId and customer_account_id = :customerId");
        query.setParameter("tenantId", tenantId);
        query.setParameter("customerId", customerId);
        BigDecimal decimal = (BigDecimal) query.getSingleResult();
        if (Objects.isNull(decimal)) {
            return BigDecimal.valueOf(0);
        }
        return decimal;
    }

    private Budget getBudget(Long consumerId) {
        List<Budget> budgetList = budgetRepository.getBudgetBy(consumerId);
        if (CollectionUtils.isEmpty(budgetList)) {
            return Budget.createEmptyBudget(consumerId);
        }
        return budgetRepository.getBudgetBy(consumerId).get(0);
    }

    public List<Tenant> getTenantList(String tenantId, String customerId) {
        Query query = entityManager.createNativeQuery("select id, name from zb_tenant where id = :tenantId");
        query.setParameter("tenantId", tenantId);
        List<Object[]> objectList = query.getResultList();
        List<Tenant> tenantList = new ArrayList<>();
        for (Object[] obj : objectList) {
            Tenant tenant = new Tenant(obj);
            tenant.setActiveSubscription(getActiveSubscriptions(tenantId, customerId));
            query = entityManager.createNativeQuery("select sum(cmrr) from zb_subscription where tenant_id = :tenantId and customer_id = :customerId");
            query.setParameter("tenantId", tenantId);
            query.setParameter("customerId", customerId);
            tenant.setMrr((BigDecimal) query.getSingleResult());
            query = entityManager.createNativeQuery("select customer_name from zb_billing_account where tenant_id = :tenantId and id = :customerId");
            query.setParameter("tenantId", tenantId);
            query.setParameter("customerId", customerId);
            tenant.setCustomerName((String) query.getSingleResult());
            tenantList.add(tenant);
        }
        return tenantList;
    }

    private Integer getActiveSubscriptions(String tenantId, String customerId) {
        Query query = entityManager.createNativeQuery("select count(*) from zb_subscription where tenant_id = :tenantId and customer_id = :customerId and status_id = 3");
        query.setParameter("tenantId", tenantId);
        query.setParameter("customerId", customerId);
        long count = (Long) query.getSingleResult();
        return (int) count;
    }
}
