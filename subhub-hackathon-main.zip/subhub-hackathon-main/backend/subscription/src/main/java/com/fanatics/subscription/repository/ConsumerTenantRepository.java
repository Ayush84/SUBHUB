package com.fanatics.subscription.repository;

import com.fanatics.subscription.domain.ConsumerTenantDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsumerTenantRepository extends JpaRepository<ConsumerTenantDetails, Long> {

    @Query(value = "select * from consumer_tenant_details where consumer_id = :consumerId", nativeQuery = true)
    List<ConsumerTenantDetails> getConsumerTenantDetailsBy(Long consumerId);

    @Query(value = "select * from consumer_tenant_details where consumer_id = :consumerId and tenant_id = :tenantId", nativeQuery = true)
    List<ConsumerTenantDetails> getConsumerTenantDetailsBy(Long consumerId, String tenantId);
}
