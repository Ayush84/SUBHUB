package com.fanatics.subscription.domain.container;

import com.fanatics.subscription.domain.SubscriptionDashboardDetails;

public class SubscriptionDashboardDetailsContainer {

    private SubscriptionDashboardDetails subscriptionDashboardDetails;
    private Long consumerId;

    public SubscriptionDashboardDetailsContainer() {}

    public SubscriptionDashboardDetails getSubscriptionDashboardDetails() {
        return subscriptionDashboardDetails;
    }

    public void setSubscriptionDashboardDetails(SubscriptionDashboardDetails subscriptionDashboardDetails) {
        this.subscriptionDashboardDetails = subscriptionDashboardDetails;
    }

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    public static SubscriptionDashboardDetailsContainer create(SubscriptionDashboardDetails subscriptionDashboardDetails, Long consumerId) {
        SubscriptionDashboardDetailsContainer container = new SubscriptionDashboardDetailsContainer();
        container.setConsumerId(consumerId);
        container.setSubscriptionDashboardDetails(subscriptionDashboardDetails);
        return container;
    }
}
