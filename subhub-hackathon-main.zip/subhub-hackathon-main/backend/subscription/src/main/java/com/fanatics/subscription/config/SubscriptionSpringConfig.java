package com.fanatics.subscription.config;

import com.fanatics.subscription.domain.ConsumerId;
import com.fanatics.subscription.event.ConsumerAccountRefreshEventHandler;
import com.fanatics.subscription.repository.BudgetRepository;
import com.fanatics.subscription.repository.ConsumerAccountRepository;
import com.fanatics.subscription.repository.ConsumerTenantRepository;
import com.fanatics.subscription.repository.CustomerContactRepository;
import com.fanatics.subscription.repository.GlobalConsumerIdCounterRepository;
import com.fanatics.subscription.repository.SubscriptionPaymentRepository;
import com.fanatics.subscription.repository.TenantMetadataRepository;
import com.fanatics.subscription.service.AccountRefreshService;
import com.fanatics.subscription.service.AccountService;
import com.fanatics.subscription.service.BudgetService;
import com.fanatics.subscription.service.GlobalConsumerIdCounterService;
import com.fanatics.subscription.service.SubscriptionDashboardService;
import com.fanatics.subscription.service.TenantMetadataService;
import com.fanatics.subscription.service.impl.AccountRefreshServiceImpl;
import com.fanatics.subscription.service.impl.AccountServiceImpl;
import com.fanatics.subscription.service.impl.BudgetServiceImpl;
import com.fanatics.subscription.service.impl.GlobalConsumerIdCounterServiceImpl;
import com.fanatics.subscription.service.impl.SubscriptionSubscriptionDashboardServiceImpl;
import com.fanatics.subscription.service.impl.TenantMetadataServiceImpl;
import com.google.common.eventbus.AsyncEventBus;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executors;

@Configuration
@EntityScan(basePackages = "com.fanatics.subscription.domain")
public class SubscriptionSpringConfig {

    private static final Logger logger = LoggerFactory.getLogger(SubscriptionSpringConfig.class);

    @Autowired
    EntityManager entityManager;
    @Autowired
    ConsumerAccountRepository consumerAccountRepository;
    @Autowired
    GlobalConsumerIdCounterRepository globalConsumerIdCounterRepository;
    @Autowired
    BudgetRepository budgetRepository;
    @Autowired
    ConsumerTenantRepository consumerTenantRepository;
    @Autowired
    CustomerContactRepository customerContactRepository;

    @Bean
    public GlobalConsumerIdCounterService globalConsumerIdCounterService() {
        return new GlobalConsumerIdCounterServiceImpl(globalConsumerIdCounterRepository);
    }
    @Bean
    public AccountService accountService() {
        return new AccountServiceImpl(consumerAccountRepository, globalConsumerIdCounterService(), asyncEventBus());
    }

    @Bean
    public BudgetService budgetService() {
        return new BudgetServiceImpl(budgetRepository);
    }

    @Bean
    public AsyncEventBus asyncEventBus() {
        return new AsyncEventBus("SubHubAsync", Executors.newFixedThreadPool(20));
    }

    @Bean
    public ConsumerAccountRefreshEventHandler consumerAccountRefreshEventHandler() {
        return new ConsumerAccountRefreshEventHandler(accountRefreshService());
    }

    @Bean
    public SubscriptionPaymentRepository subscriptionPaymentRepository() {
        return new SubscriptionPaymentRepository(entityManager, budgetRepository);
    }

    @Bean
    public SubscriptionDashboardService subscriptionDashboardService() {
        return new SubscriptionSubscriptionDashboardServiceImpl(subscriptionPaymentRepository(), consumerTenantRepository, budgetRepository);
    }

    @Bean
    public TenantMetadataRepository tenantMetadataRepository() {
        return new TenantMetadataRepository(entityManager);
    }

    @Bean
    public TenantMetadataService tenantMetadataService() {
        return new TenantMetadataServiceImpl(tenantMetadataRepository(), consumerTenantRepository);
    }

    @Bean
    public AccountRefreshService accountRefreshService() {
        return new AccountRefreshServiceImpl(consumerTenantRepository, customerContactRepository, subscriptionDashboardService(), tenantMetadataService(), budgetRepository);
    }

    @PostConstruct
    public void init() {
        asyncEventBus().register(consumerAccountRefreshEventHandler());
        if (globalConsumerIdCounterRepository.getCount() == 0) {
            ConsumerId consumerId = ConsumerId.init();
            globalConsumerIdCounterRepository.save(consumerId);
        }
    }
}
