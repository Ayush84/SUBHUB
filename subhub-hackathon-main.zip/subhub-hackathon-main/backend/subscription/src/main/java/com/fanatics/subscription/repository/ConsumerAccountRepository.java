package com.fanatics.subscription.repository;

import com.fanatics.subscription.domain.ConsumerAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsumerAccountRepository extends JpaRepository<ConsumerAccount, String> {

    List<ConsumerAccount> findByEmailId(String emailId);
}
