package com.fanatics.subscription.service.impl;

import com.fanatics.subscription.domain.ConsumerTenantDetails;
import com.fanatics.subscription.domain.TenantDetail;
import com.fanatics.subscription.domain.container.SubscriptionDashboardDetailsContainer;
import com.fanatics.subscription.repository.ConsumerTenantRepository;
import com.fanatics.subscription.repository.TenantMetadataRepository;
import com.fanatics.subscription.service.TenantMetadataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TenantMetadataServiceImpl implements TenantMetadataService {

    private static final Logger logger = LoggerFactory.getLogger(TenantMetadataServiceImpl.class);

    private TenantMetadataRepository tenantMetadataRepository;
    private ConsumerTenantRepository consumerTenantRepository;
    private Map<String, TenantDetail> tenantDetailCache;

    public TenantMetadataServiceImpl(TenantMetadataRepository tenantMetadataRepository, ConsumerTenantRepository consumerTenantRepository) {
        this.tenantMetadataRepository = tenantMetadataRepository;
        this.consumerTenantRepository = consumerTenantRepository;
        this.tenantDetailCache = new ConcurrentHashMap<>();
    }

    @Override
    public TenantDetail getTenantDetail(Long consumerId, String tenantId, boolean forceUpdateCache) {
        if (!forceUpdateCache && tenantDetailCache.containsKey(tenantId)) {
            return tenantDetailCache.get(tenantId);
        }
        List<ConsumerTenantDetails> consumerTenantDetailsList = consumerTenantRepository.getConsumerTenantDetailsBy(consumerId, tenantId);
        if (CollectionUtils.isEmpty(consumerTenantDetailsList)) {
            return new TenantDetail();
        }
        ConsumerTenantDetails consumerTenantDetails = consumerTenantRepository.getConsumerTenantDetailsBy(consumerId, tenantId).get(0);
        TenantDetail tenantDetail = tenantMetadataRepository.getTenantDetail(tenantId, consumerTenantDetails.getCustomerId());
        tenantDetailCache.put(tenantId, tenantDetail);
        return tenantDetail;
    }

    @Override
    public void updateTenantDetailCache(String tenantId, TenantDetail detail) {
        tenantDetailCache.put(tenantId, detail);
    }
}
