package com.fanatics.subscription.rest;

import com.fanatics.subscription.domain.SubscriptionDashboardDetails;
import com.fanatics.subscription.domain.TenantDetail;
import com.fanatics.subscription.service.SubscriptionDashboardService;
import com.fanatics.subscription.service.TenantMetadataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:5173", maxAge = 3600)
public class TenantMetadataRestResource {

    @Autowired
    TenantMetadataService tenantMetadataService;


    @GetMapping("/tenant")
    public ResponseEntity<TenantDetail> getDashboard(@RequestParam("consumerId") Long consumerId, @RequestParam("tenantId") String tenantId, @RequestParam(value = "force", defaultValue = "false") boolean forceUpdateCache) {
        return ResponseEntity.ok(tenantMetadataService.getTenantDetail(consumerId, tenantId, forceUpdateCache));
    }
}
