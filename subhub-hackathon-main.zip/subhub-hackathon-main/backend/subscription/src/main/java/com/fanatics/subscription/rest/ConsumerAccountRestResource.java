package com.fanatics.subscription.rest;

import com.fanatics.subscription.domain.ConsumerAccount;
import com.fanatics.subscription.domain.ConsumerEmailDetails;
import com.fanatics.subscription.service.AccountService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@RestController
@CrossOrigin(origins = "http://localhost:5173", maxAge = 3600)
public class ConsumerAccountRestResource {
    private static final Logger logger = LoggerFactory.getLogger(ConsumerAccountRestResource.class);

    @Autowired
    protected AccountService accountService;

    @PostMapping("/accounts")
    public ResponseEntity<ConsumerAccount> createAccount(@RequestBody ConsumerEmailDetails emailDetails) {
        if (Objects.isNull(emailDetails) || CollectionUtils.isEmpty(emailDetails.getEmailIds())) {
            return ResponseEntity.ok(null);
        }
        List<String> existingEmailIds = new ArrayList<>();
        List<ConsumerAccount> existingAccounts = new ArrayList<>();
        for (String emailId : emailDetails.getEmailIds()) {
            List<ConsumerAccount> accountList = accountService.findAccounts(emailId);
            if (!CollectionUtils.isEmpty(accountList)) {
                existingEmailIds.add(emailId);
                existingAccounts.add(accountList.get(0));
            }
        }
        if (!CollectionUtils.isEmpty(existingEmailIds)) {
            System.out.println("Not adding the Email Ids which are already existing in system. " + existingEmailIds);
            emailDetails.getEmailIds().removeAll(existingEmailIds);
            return ResponseEntity.ok(existingAccounts.get(0));
        }
        else {
            return ResponseEntity.ok(accountService.createAccount(emailDetails.getEmailIds()));
        }
    }
}
