package com.fanatics.subscription.repository;

import com.fanatics.subscription.domain.ConsumerId;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface GlobalConsumerIdCounterRepository extends JpaRepository<ConsumerId, Integer> {

    @Transactional
    @Modifying
    @Query(value = "update counter set counter = counter+1", nativeQuery = true)
    void updateCounter();

    @Query(value = "select counter from counter", nativeQuery = true)
    Integer getCounter();

    @Query(value = "select count(*) from counter", nativeQuery = true)
    int getCount();
}
