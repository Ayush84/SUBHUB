package com.fanatics.subscription.repository;

import com.fanatics.subscription.domain.Budget;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {

    @Query(value = "select * from budget where consumer_id = :consumerId", nativeQuery = true)
    List<Budget> getBudgetBy(Long consumerId);

    @Transactional
    @Modifying
    @Query(value = "update budget set amount = :amount where consumer_id = :consumerId", nativeQuery = true)
    void updateBudgetBy(Long consumerId, BigDecimal amount);
}
