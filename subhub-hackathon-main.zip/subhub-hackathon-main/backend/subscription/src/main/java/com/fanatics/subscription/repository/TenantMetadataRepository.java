package com.fanatics.subscription.repository;

import com.fanatics.subscription.domain.Subscription;
import com.fanatics.subscription.domain.TenantDetail;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import java.util.ArrayList;
import java.util.List;

public class TenantMetadataRepository {

    private EntityManager entityManager;

    public TenantMetadataRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public TenantDetail getTenantDetail(String tenantId, String customerId) {
        Query query = entityManager.createNativeQuery("select zt.name, zba.customer_name, zs.subscription_name, zs.cmrr, zs.next_charge_date, zs.subscription_end_date, zs.status_id from zb_subscription zs join zb_billing_account zba on zs.customer_id = zba.id and zs.status_id in ('0' , '1', '2', '3', '4', '6') join zb_tenant zt on zt.id=zs.tenant_id  where zs.tenant_id = :tenantId and zs.customer_id=:customerId");
        query.setParameter("tenantId", tenantId);
        query.setParameter("customerId", customerId);
        List<Object[]> objectList = query.getResultList();
        TenantDetail detail = TenantDetail.parseAndCreateTenant(objectList.get(0));
        List<Subscription> subscriptionList = new ArrayList<>();
        for (Object[] obj : objectList) {
            Subscription subscription = Subscription.parseAndCreateSubscription(obj);
            subscriptionList.add(subscription);
        }
        detail.setSubscriptionList(subscriptionList);
        detail.setActiveSubscription(TenantDetail.getActiveSubscription(detail));
        return detail;
    }
}
