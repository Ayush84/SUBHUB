package com.fanatics.subscription.service.impl;

import com.fanatics.subscription.domain.ConsumerTenantDetails;
import com.fanatics.subscription.domain.SubscriptionDashboardDetails;
import com.fanatics.subscription.domain.container.SubscriptionDashboardDetailsContainer;
import com.fanatics.subscription.repository.BudgetRepository;
import com.fanatics.subscription.repository.ConsumerTenantRepository;
import com.fanatics.subscription.repository.SubscriptionPaymentRepository;
import com.fanatics.subscription.service.SubscriptionDashboardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

public class SubscriptionSubscriptionDashboardServiceImpl implements SubscriptionDashboardService {

    private static final Logger logger = LoggerFactory.getLogger(SubscriptionSubscriptionDashboardServiceImpl.class);

    private SubscriptionPaymentRepository subscriptionPaymentRepository;
    private ConsumerTenantRepository consumerTenantRepository;
    private Map<Long, SubscriptionDashboardDetailsContainer> subscriptionDashboardDetailsContainerCache;
    private BudgetRepository budgetRepository;

    public SubscriptionSubscriptionDashboardServiceImpl(SubscriptionPaymentRepository subscriptionPaymentRepository, ConsumerTenantRepository consumerTenantRepository, BudgetRepository budgetRepository) {
        this.subscriptionPaymentRepository = subscriptionPaymentRepository;
        this.consumerTenantRepository = consumerTenantRepository;
        this.budgetRepository = budgetRepository;
        this.subscriptionDashboardDetailsContainerCache = new ConcurrentHashMap<>();
    }

    @Override
    public SubscriptionDashboardDetails getDashboardDetails(Long consumerId, boolean forceUpdateCache) {
        if (!forceUpdateCache && subscriptionDashboardDetailsContainerCache.containsKey(consumerId)) {
            return subscriptionDashboardDetailsContainerCache.get(consumerId).getSubscriptionDashboardDetails();
        }
        List<ConsumerTenantDetails> consumerTenantDetails = consumerTenantRepository.getConsumerTenantDetailsBy(consumerId);
        SubscriptionDashboardDetails details = subscriptionPaymentRepository.getDashboardDetails(consumerTenantDetails);
        if (Objects.isNull(details)) {
            return null;
        }
        updateSubscriptionDashboardCache(consumerId, details);
        budgetRepository.updateBudgetBy(consumerId, details.getNmrr());
        return details;
    }

    @Override
    public SubscriptionDashboardDetails getDashboardDetailsCache(Long consumerId) {
        if (subscriptionDashboardDetailsContainerCache.containsKey(consumerId)) {
            return subscriptionDashboardDetailsContainerCache.get(consumerId).getSubscriptionDashboardDetails();
        }
        return null;
    }

    public void updateSubscriptionDashboardCache(Long consumerId, SubscriptionDashboardDetails subscriptionDashboardDetails) {
        subscriptionDashboardDetailsContainerCache.put(consumerId, SubscriptionDashboardDetailsContainer.create(subscriptionDashboardDetails, consumerId));
    }
}
