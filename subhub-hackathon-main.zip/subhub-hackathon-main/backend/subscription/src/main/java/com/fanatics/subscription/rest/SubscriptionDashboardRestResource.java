package com.fanatics.subscription.rest;

import com.fanatics.subscription.domain.SubscriptionDashboardDetails;
import com.fanatics.subscription.service.SubscriptionDashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:5173", maxAge = 3600)
public class SubscriptionDashboardRestResource {

    @Autowired
    SubscriptionDashboardService subscriptionDashboardService;


    @GetMapping("/dashboard")
    public ResponseEntity<SubscriptionDashboardDetails> getDashboard(@RequestParam("consumerId") Long consumerId, @RequestParam(value = "force", defaultValue = "false") boolean forceUpdateCache) {
        return ResponseEntity.ok(subscriptionDashboardService.getDashboardDetails(consumerId, forceUpdateCache));
    }
}
