package com.fanatics.subscription.service.impl;

import com.fanatics.subscription.domain.Budget;
import com.fanatics.subscription.domain.Period;
import com.fanatics.subscription.repository.BudgetRepository;
import com.fanatics.subscription.service.BudgetService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class BudgetServiceImpl implements BudgetService {

    private static final Logger logger = LoggerFactory.getLogger(BudgetServiceImpl.class);

    private BudgetRepository budgetRepository;

    public BudgetServiceImpl(BudgetRepository budgetRepository) {
        this.budgetRepository = budgetRepository;
    }

    @Override
    public Budget getLatestBudget(String emailId, Period period) {
        return null;
    }

    @Override
    public List<Budget> getBudget(String emailId) {
        return null;
    }

    @Override
    public Budget updateCurrentBudget(Budget budget) {
        return null;
    }

    @Override
    public Budget createBudget(Budget budget) {
        return budgetRepository.save(budget);
    }
}
