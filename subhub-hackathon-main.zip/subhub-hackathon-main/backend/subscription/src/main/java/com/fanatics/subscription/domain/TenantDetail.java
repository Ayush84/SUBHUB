package com.fanatics.subscription.domain;

import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.List;

public class TenantDetail {

    private String name;
    private String consumerName;
    private Integer activeSubscription;
    private List<Subscription> subscriptionList;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getActiveSubscription() {
        return activeSubscription;
    }

    public void setActiveSubscription(Integer activeSubscription) {
        this.activeSubscription = activeSubscription;
    }

    public List<Subscription> getSubscriptionList() {
        return subscriptionList;
    }

    public void setSubscriptionList(List<Subscription> subscriptionList) {
        this.subscriptionList = subscriptionList;
    }

    public String getConsumerName() {
        return consumerName;
    }

    public void setConsumerName(String consumerName) {
        this.consumerName = consumerName;
    }

    public static TenantDetail create(String tenantName, String consumerName) {
        TenantDetail tenantDetail = new TenantDetail();
        tenantDetail.setConsumerName(consumerName);
        tenantDetail.setName(tenantName);
        return tenantDetail;
    }

    public static TenantDetail parseAndCreateTenant(Object[] object) {
        return create((String) object[0], (String) object[1]);
    }

    public static int getActiveSubscription(TenantDetail tenantDetail) {
        if (CollectionUtils.isEmpty(tenantDetail.getSubscriptionList())) {
            return 0;
        }
        return (int) tenantDetail.getSubscriptionList().stream().filter(subscription -> {return subscription.getStatus() == StatusEnum.ACTIVE;}).count();
    }
}
