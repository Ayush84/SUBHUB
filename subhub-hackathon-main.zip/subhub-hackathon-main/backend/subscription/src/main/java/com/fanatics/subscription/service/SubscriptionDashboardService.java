package com.fanatics.subscription.service;

import com.fanatics.subscription.domain.SubscriptionDashboardDetails;

public interface SubscriptionDashboardService {

    SubscriptionDashboardDetails getDashboardDetails(Long consumerId, boolean forceUpdateCache);
    SubscriptionDashboardDetails getDashboardDetailsCache(Long consumerId);
}
