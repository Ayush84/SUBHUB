package com.fanatics.subscription.service.impl;

import com.fanatics.subscription.domain.BillingAccountDetails;
import com.fanatics.subscription.domain.Budget;
import com.fanatics.subscription.domain.ConsumerTenantDetails;
import com.fanatics.subscription.repository.BudgetRepository;
import com.fanatics.subscription.repository.ConsumerTenantRepository;
import com.fanatics.subscription.repository.CustomerContactRepository;
import com.fanatics.subscription.service.AccountRefreshService;
import com.fanatics.subscription.service.SubscriptionDashboardService;
import com.fanatics.subscription.service.TenantMetadataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.List;

public class AccountRefreshServiceImpl implements AccountRefreshService {

    private static final Logger logger = LoggerFactory.getLogger(AccountRefreshServiceImpl.class);

    private ConsumerTenantRepository consumerTenantRepository;
    private CustomerContactRepository customerContactRepository;
    private SubscriptionDashboardService subscriptionDashboardService;
    private TenantMetadataService tenantMetadataService;
    private BudgetRepository budgetRepository;

    public AccountRefreshServiceImpl(ConsumerTenantRepository consumerTenantRepository, CustomerContactRepository customerContactRepository, SubscriptionDashboardService subscriptionDashboardService, TenantMetadataService tenantMetadataService, BudgetRepository budgetRepository) {
        this.consumerTenantRepository = consumerTenantRepository;
        this.customerContactRepository = customerContactRepository;
        this.subscriptionDashboardService = subscriptionDashboardService;
        this.tenantMetadataService = tenantMetadataService;
        this.budgetRepository = budgetRepository;
    }

    @Override
    public void refreshAccount(Long consumerId, List<String> emailIds) {
        if (CollectionUtils.isEmpty(emailIds)) {
            return;
        }
        String emailIdsAsString = String.join(",", emailIds);
        List<BillingAccountDetails> billingAccountDetails = customerContactRepository.getBillingAccountDetailsBy(emailIdsAsString);
        for (BillingAccountDetails billingAccountDetail : billingAccountDetails) {
            ConsumerTenantDetails consumerTenantDetails = ConsumerTenantDetails.createConsumerTenantDetails(billingAccountDetail, consumerId);
            consumerTenantRepository.save(consumerTenantDetails);
            tenantMetadataService.getTenantDetail(consumerId, billingAccountDetail.getTenantId(), true);
        }
        Budget budget = Budget.createBudget(consumerId, emailIds.get(0));
        budgetRepository.save(budget);
        subscriptionDashboardService.getDashboardDetails(consumerId, true);
    }
}
