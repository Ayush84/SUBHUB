package com.fanatics.subscription.event;

import com.fanatics.subscription.domain.event.ConsumerAccountRefreshedEvent;
import com.fanatics.subscription.service.AccountRefreshService;
import com.google.common.eventbus.Subscribe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ConsumerAccountRefreshEventHandler {

    private static final Logger logger = LoggerFactory.getLogger(ConsumerAccountRefreshEventHandler.class);

    private AccountRefreshService accountRefreshService;

    public ConsumerAccountRefreshEventHandler(AccountRefreshService accountRefreshService) {
        this.accountRefreshService = accountRefreshService;
    }

    @Subscribe
    public void handleAccountRefreshEvent(ConsumerAccountRefreshedEvent consumerAccountRefreshedEvent) {
        System.out.println("Consumer Account Refreshed Event received :" + consumerAccountRefreshedEvent);
        accountRefreshService.refreshAccount(consumerAccountRefreshedEvent.getConsumerId(), List.of(consumerAccountRefreshedEvent.getEmailId()));
    }
}
