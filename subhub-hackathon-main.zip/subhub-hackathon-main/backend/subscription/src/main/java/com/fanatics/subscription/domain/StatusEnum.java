package com.fanatics.subscription.domain;


public enum StatusEnum {
    DRAFT("Draft", 0),
    ACTIVE("Active", 3),
    CANCELLED("Cancelled", 4),
    SUSPENDED("Suspended", 6);

    private String label;
    private int number;

    StatusEnum(String label, int number) {
        this.label = label;
        this.number = number;
    }

    public String getLabel() {
        return label;
    }

    public int getNumber() {
        return number;
    }

    public static StatusEnum from(int number) {
        for (StatusEnum statusEnum : StatusEnum.values()) {
            if (statusEnum.getNumber() == number) {
                return statusEnum;
            }
        }
        return StatusEnum.DRAFT;
    }
}
