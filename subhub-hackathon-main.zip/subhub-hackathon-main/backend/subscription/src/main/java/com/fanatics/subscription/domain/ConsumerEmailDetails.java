package com.fanatics.subscription.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ConsumerEmailDetails {
    private List<String> emailIds;

    @JsonProperty("emailIds")
    public List<String> getEmailIds() {
        return emailIds;
    }

    public void setEmailIds(List<String> emailIds) {
        this.emailIds = emailIds;
    }
}
