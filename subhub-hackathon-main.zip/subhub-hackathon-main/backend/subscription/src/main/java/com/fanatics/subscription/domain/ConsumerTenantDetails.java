package com.fanatics.subscription.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "consumer_tenant_details")
public class ConsumerTenantDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @Column(name = "consumer_id", nullable = false)
    private Long consumerId;

    @Column(name = "tenant_id", nullable = false)
    private String tenantId;

    @Column(name = "customer_id", nullable = false)
    private String customerId;

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long consumerId) {
        this.consumerId = consumerId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o, new String[]{"id"});
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, new String[]{"id"});
    }

    public static ConsumerTenantDetails createConsumerTenantDetails(BillingAccountDetails billingAccountDetails, Long consumerId) {
        ConsumerTenantDetails consumerTenantDetails = new ConsumerTenantDetails();
        consumerTenantDetails.setCustomerId(billingAccountDetails.getCustomerId());
        consumerTenantDetails.setTenantId(billingAccountDetails.getTenantId());
        consumerTenantDetails.setConsumerId(consumerId);
        return consumerTenantDetails;
    }
}
