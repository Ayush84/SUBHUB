package com.fanatics.subscription.service.impl;

import com.fanatics.subscription.domain.ConsumerAccount;
import com.fanatics.subscription.domain.event.ConsumerAccountRefreshedEvent;
import com.fanatics.subscription.repository.ConsumerAccountRepository;
import com.fanatics.subscription.service.AccountService;
import com.fanatics.subscription.service.GlobalConsumerIdCounterService;
import com.google.common.eventbus.AsyncEventBus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.List;

public class AccountServiceImpl implements AccountService {

    private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

    private ConsumerAccountRepository consumerAccountRepository;
    private GlobalConsumerIdCounterService globalConsumerIdCounterService;
    private AsyncEventBus asyncEventBus;
    public AccountServiceImpl(ConsumerAccountRepository consumerAccountRepository, GlobalConsumerIdCounterService globalConsumerIdCounterService, AsyncEventBus asyncEventBus) {
        this.consumerAccountRepository = consumerAccountRepository;
        this.globalConsumerIdCounterService = globalConsumerIdCounterService;
        this.asyncEventBus = asyncEventBus;
    }

    @Override
    public ConsumerAccount createAccount(List<String> emailIds) {
        if (CollectionUtils.isEmpty(emailIds)) {
            return null;
        }
        long counter = globalConsumerIdCounterService.findAndUpdateCounter();
        ConsumerAccount consumerAccount = null;
        for (String emailId : emailIds) {
            consumerAccount = consumerAccountRepository.save(ConsumerAccount.createAccount(counter, emailId));
            asyncEventBus.post(new ConsumerAccountRefreshedEvent(consumerAccount.getConsumerId(), consumerAccount.getEmailId()));
        }
        return consumerAccount;
    }

    @Override
    public List<ConsumerAccount> findAccounts(String emailId) {
        return consumerAccountRepository.findByEmailId(emailId);
    }

    @Override
    public ConsumerAccount linkAccount(String parentEmailId, String emailId) {
        ConsumerAccount parentAccount = consumerAccountRepository.findByEmailId(parentEmailId).get(0);
        return consumerAccountRepository.save(ConsumerAccount.createAccount(parentAccount.getConsumerId(), emailId, parentEmailId));
    }

    @Override
    public ConsumerAccount unlinkAccount(String parentEmailId, String emailId) {
        return null;
    }

    @Override
    public ConsumerAccount removeAccount(String emailId) {
        return null;
    }
}
