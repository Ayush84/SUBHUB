package com.fanatics.subscription.domain;

public enum Period {
    MONTHLY("Monthly"),
    QUARTERLY("Quarterly"),
    HALFYEARLY("HalfYearly"),
    YEARLY("Yearly");

    private String label;

    Period(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
