package com.fanatics.subscription.service;

import java.util.List;

public interface AccountRefreshService {

    void refreshAccount(Long consumerId, List<String> emailIds);

}
