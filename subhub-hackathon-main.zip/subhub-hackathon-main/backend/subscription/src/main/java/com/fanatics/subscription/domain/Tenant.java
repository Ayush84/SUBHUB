package com.fanatics.subscription.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.math.BigDecimal;
import java.util.List;

public class Tenant {

    private String id;
    private String name;

    private String customerName;
    private Integer activeSubscription;
    private BigDecimal mrr;

    public Tenant(Object[] object) {
        this.id = (String) object[0];
        this.name = (String) object[1];
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("customerName")
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    @JsonProperty("activeSubscription")
    public Integer getActiveSubscription() {
        return activeSubscription;
    }

    public void setActiveSubscription(Integer activeSubscription) {
        this.activeSubscription = activeSubscription;
    }

    @JsonProperty("mrr")
    public BigDecimal getMrr() {
        return mrr;
    }

    public void setMrr(BigDecimal mrr) {
        this.mrr = mrr;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o, new String[]{});
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, new String[]{});
    }
}
