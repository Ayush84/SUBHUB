package com.fanatics.subscription.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.print.DocFlavor.STRING;

public class Subscription {

    private String name;
    private BigDecimal amount;
    private Date nextRenewalDate;
    private Date endDate;
    private StatusEnum status;
    private List<String> productList;

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("amount")
    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @JsonProperty("nextRenewalDate")
    public Date getNextRenewalDate() {
        return nextRenewalDate;
    }

    public void setNextRenewalDate(Date nextRenewalDate) {
        this.nextRenewalDate = nextRenewalDate;
    }

    @JsonProperty("endDate")
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @JsonProperty("status")
    public StatusEnum getStatus() {
        return status;
    }

    public void setStatus(StatusEnum status) {
        this.status = status;
    }

    @JsonProperty("productList")
    public List<String> getProductList() {
        return productList;
    }

    public void setProductList(List<String> productList) {
        this.productList = productList;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o, new String[] {});
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, new String[] {});
    }

    public static Subscription createSubscription(String name, BigDecimal amount, Date nextRenewalDate, Date endDate, int statusNumber) {
        Subscription subscription = new Subscription();
        subscription.setName(name);
        subscription.setAmount(amount);
        subscription.setNextRenewalDate(nextRenewalDate);
        subscription.setEndDate(endDate);
        subscription.setStatus(StatusEnum.from(statusNumber));
        return subscription;
    }

    public static Subscription parseAndCreateSubscription(Object[] object) {
        return createSubscription((String) object[2], (BigDecimal) object[3], (Date) object[4], (Date) object[5], Integer.valueOf((String) object[6]));
    }
}
