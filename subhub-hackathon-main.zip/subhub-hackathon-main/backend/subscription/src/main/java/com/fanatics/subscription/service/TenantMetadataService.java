package com.fanatics.subscription.service;

import com.fanatics.subscription.domain.TenantDetail;

public interface TenantMetadataService {
    TenantDetail getTenantDetail(Long consumerId, String tenantId, boolean forceUpdateCache);
    void updateTenantDetailCache(String tenantId, TenantDetail detail);
}
