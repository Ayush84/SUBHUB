package com.fanatics.subscription.service.impl;

import com.fanatics.subscription.repository.GlobalConsumerIdCounterRepository;
import com.fanatics.subscription.service.GlobalConsumerIdCounterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GlobalConsumerIdCounterServiceImpl implements GlobalConsumerIdCounterService {

    private static final Logger logger = LoggerFactory.getLogger(GlobalConsumerIdCounterServiceImpl.class);

    private GlobalConsumerIdCounterRepository globalConsumerIdCounterRepository;

    public GlobalConsumerIdCounterServiceImpl(GlobalConsumerIdCounterRepository globalConsumerIdCounterRepository) {
        this.globalConsumerIdCounterRepository = globalConsumerIdCounterRepository;
    }


    @Override
    public long getCounter() {
        return globalConsumerIdCounterRepository.getCounter();
    }

    @Override
    public synchronized long findAndUpdateCounter() {
        globalConsumerIdCounterRepository.updateCounter();
        return globalConsumerIdCounterRepository.getCounter();
    }
}
