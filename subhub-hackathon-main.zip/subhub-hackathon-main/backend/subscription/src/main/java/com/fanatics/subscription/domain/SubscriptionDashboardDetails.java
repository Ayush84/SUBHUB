package com.fanatics.subscription.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;

import java.math.BigDecimal;
import java.util.List;

public class SubscriptionDashboardDetails {

    private Integer totalSubscription;
    private BigDecimal paid;
    private BigDecimal nmrr;
    private Budget budget;
    private List<Tenant> tenants;

    @JsonProperty("totalSubscription")
    public Integer getTotalSubscription() {
        return totalSubscription;
    }

    public void setTotalSubscription(Integer totalSubscription) {
        this.totalSubscription = totalSubscription;
    }

    @JsonProperty("paid")
    public BigDecimal getPaid() {
        return paid;
    }

    public void setPaid(BigDecimal paid) {
        this.paid = paid;
    }

    @JsonProperty("nmrr")
    public BigDecimal getNmrr() {
        return nmrr;
    }

    public void setNmrr(BigDecimal nmrr) {
        this.nmrr = nmrr;
    }

    @JsonProperty("budget")
    public Budget getBudget() {
        return budget;
    }

    public void setBudget(Budget budget) {
        this.budget = budget;
    }

    @JsonProperty("tenants")
    public List<Tenant> getTenants() {
        return tenants;
    }

    public void setTenants(List<Tenant> tenants) {
        this.tenants = tenants;
    }

    public static SubscriptionDashboardDetails createSubscriptionDashboardDetails(Integer totalSubscription, BigDecimal paid, BigDecimal nmrr, Budget budget, List<Tenant> tenants) {
        SubscriptionDashboardDetails subscriptionDashboardDetails = new SubscriptionDashboardDetails();
        subscriptionDashboardDetails.setTotalSubscription(totalSubscription);
        subscriptionDashboardDetails.setPaid(paid);
        subscriptionDashboardDetails.setBudget(budget);
        subscriptionDashboardDetails.setNmrr(nmrr);
        subscriptionDashboardDetails.setTenants(tenants);
        return subscriptionDashboardDetails;
    }
}
