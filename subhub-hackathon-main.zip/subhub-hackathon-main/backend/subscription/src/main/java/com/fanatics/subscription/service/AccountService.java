package com.fanatics.subscription.service;

import com.fanatics.subscription.domain.ConsumerAccount;

import java.util.List;

public interface AccountService {

    ConsumerAccount createAccount(List<String> emailId);
    List<ConsumerAccount> findAccounts(String emailId);
    ConsumerAccount linkAccount(String parentEmailId, String emailId);
    ConsumerAccount unlinkAccount(String parentEmailId, String emailId);
    ConsumerAccount removeAccount(String emailId);
}
