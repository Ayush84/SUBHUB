package com.fanatics.subscription.service;

import com.fanatics.subscription.domain.Budget;
import com.fanatics.subscription.domain.Period;

import java.util.List;

public interface BudgetService {

    Budget getLatestBudget(String emailId, Period period);

    List<Budget> getBudget(String emailId);

    Budget updateCurrentBudget(Budget budget);

    Budget createBudget(Budget budget);
}
