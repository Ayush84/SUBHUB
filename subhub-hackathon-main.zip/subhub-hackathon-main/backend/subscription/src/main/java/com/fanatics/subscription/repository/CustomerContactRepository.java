package com.fanatics.subscription.repository;

import com.fanatics.subscription.domain.BillingAccountDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CustomerContactRepository extends JpaRepository<BillingAccountDetails, Long> {

    @Query(value = "select id, billing_account_id, tenant_id from zb_contact_snapshot where work_email in (:emailIds)", nativeQuery = true)
    List<BillingAccountDetails> getBillingAccountDetailsBy(String emailIds);
}
