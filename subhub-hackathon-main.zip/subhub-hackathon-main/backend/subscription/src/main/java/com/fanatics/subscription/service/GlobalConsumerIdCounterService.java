package com.fanatics.subscription.service;

public interface GlobalConsumerIdCounterService {
    long getCounter();
    long findAndUpdateCounter();
}
