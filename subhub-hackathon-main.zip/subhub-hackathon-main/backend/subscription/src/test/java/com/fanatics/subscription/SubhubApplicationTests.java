package com.fanatics.subscription;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
